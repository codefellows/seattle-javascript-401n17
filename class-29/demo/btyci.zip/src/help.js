import React from "react";

export default function Help() {
  return <div>Ask me any question, Zoltar knows all</div>;
}
