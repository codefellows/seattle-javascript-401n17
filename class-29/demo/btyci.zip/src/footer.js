import React from "react";

function Footer() {
  return <footer>&copy; 2020 John</footer>;
}

export default Footer;
